import torch
import numpy as np
from typing import Dict, List, Optional
from y2h_ppi.logger import logger
from y2h_ppi.features.classic_descriptors import extract_classical_descriptors

class ESMEmbeddingExtractor:
    """ESM-2 protein language model embedding extractor with fast CPU capping & fallback."""
    
    def __init__(self, model_name: str = "facebook/esm2_t6_8M_UR50D", device: str = "cpu"):
        self.model_name = model_name
        self.device = device
        self.tokenizer = None
        self.model = None
        self._is_loaded = False
        
    def _load_model(self):
        if self._is_loaded:
            return
        try:
            from transformers import AutoTokenizer, AutoModel
            logger.info(f"Loading ESM-2 model '{self.model_name}' on {self.device}...")
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
            self.model = AutoModel.from_pretrained(self.model_name)
            self.model.eval()
            self.model.to(self.device)
            self._is_loaded = True
            logger.info("ESM-2 model successfully loaded.")
        except Exception as e:
            logger.warning(f"Could not load ESM-2 model '{self.model_name}' ({e}). Using fallback.")
            self._is_loaded = False
            
    def embed_sequences_batch(self, sequences: List[str], batch_size: int = 32, max_esm_count: int = 500) -> List[np.ndarray]:
        """Extract mean-pooled ESM-2 protein embeddings for up to max_esm_count proteins, fallback for remaining."""
        self._load_model()
        results = []
        n_seqs = len(sequences)
        
        if self._is_loaded and self.model is not None and self.tokenizer is not None:
            logger.info(f"Extracting ESM-2 embeddings for first {min(n_seqs, max_esm_count)} sequences...")
            
            for i in range(0, min(n_seqs, max_esm_count), batch_size):
                batch_seqs = sequences[i:i + batch_size]
                try:
                    inputs = self.tokenizer(batch_seqs, return_tensors="pt", padding=True, truncation=True, max_length=256)
                    inputs = {k: v.to(self.device) for k, v in inputs.items()}
                    with torch.no_grad():
                        outputs = self.model(**inputs)
                        hidden = outputs.last_hidden_state
                        mask = inputs['attention_mask'].unsqueeze(-1)
                        sum_embeddings = (hidden * mask).sum(dim=1)
                        sum_mask = mask.sum(dim=1).clamp(min=1)
                        mean_embeddings = (sum_embeddings / sum_mask).cpu().numpy()
                        
                        for emb in mean_embeddings:
                            results.append(emb.astype(np.float32))
                except Exception as e:
                    for seq in batch_seqs:
                        results.append(self._fallback_embed(seq))
                        
            # Remainder sequences use classical descriptor slice fallback
            for i in range(len(results), n_seqs):
                results.append(self._fallback_embed(sequences[i]))
                
            return results
            
        return [self._fallback_embed(seq) for seq in sequences]

    def _fallback_embed(self, sequence: str) -> np.ndarray:
        desc = extract_classical_descriptors(sequence)
        if len(desc) >= 320:
            return desc[:320].astype(np.float32)
        else:
            return np.pad(desc, (0, 320 - len(desc))).astype(np.float32)

    def embed_sequence(self, sequence: str) -> np.ndarray:
        return self.embed_sequences_batch([sequence])[0]
