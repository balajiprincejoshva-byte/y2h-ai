import json
from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse, FileResponse
from y2h_ppi.api.schemas import PredictRequest, BatchPredictRequest, PredictResponse, NetworkResponse
from y2h_ppi.inference.predictor import PPIPredictor
from y2h_ppi.network.graph_builder import build_protein_network
from fastapi.responses import JSONResponse, FileResponse
import pandas as pd

app = FastAPI(
    title="Y2H-AI API Platform",
    description="AI-Driven Computational Platform for Yeast Protein-Protein Interaction Prediction",
    version="0.1.0"
)

predictor = PPIPredictor()

@app.get("/health")
def health_check():
    return {"status": "ok", "service": "Y2H-AI Prediction Platform", "version": "0.1.0"}

@app.post("/predict", response_model=PredictResponse)
def predict_pair(req: PredictRequest):
    res = predictor.predict_pair(
        protein_a=req.protein_a,
        protein_b=req.protein_b,
        seq_a=req.sequence_a,
        seq_b=req.sequence_b
    )
    return res

@app.post("/predict/batch")
def predict_batch(req: BatchPredictRequest):
    if len(req.pairs) > 500:
        raise HTTPException(status_code=400, detail="Batch size exceeds maximum limit of 500 pairs.")
    res = predictor.predict_batch(req.pairs)
    return {"results": res, "total_scored": len(res)}

@app.get("/protein/{protein_id}/known_interactors", response_model=NetworkResponse)
def get_known_interactors(protein_id: str):
    net_data = build_protein_network(protein_id)
    return net_data

@app.get("/model/metrics")
def get_model_metrics():
    report_path = Path("reports/evaluation_report.json")
    if not report_path.exists():
        raise HTTPException(status_code=444, detail="Evaluation report not found. Run Phase 5 pipeline first.")
    with open(report_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data

@app.get("/model/card")
def get_model_card():
    card_path = Path("reports/model_card.md")
    if not card_path.exists():
        raise HTTPException(status_code=404, detail="Model card not found.")
    return FileResponse(card_path, media_type="text/markdown")

@app.get("/model/ablation")
def get_model_ablation():
    ablation_path = Path("reports/ablation_results.json")
    if not ablation_path.exists():
        raise HTTPException(status_code=404, detail="Ablation results not found.")
    with open(ablation_path, "r", encoding="utf-8") as f:
        return json.load(f)

@app.get("/provenance")
def get_provenance():
    manifest_path = Path("reports/run_manifest.json")
    if not manifest_path.exists():
        raise HTTPException(status_code=404, detail="Manifest not found.")
    with open(manifest_path, "r", encoding="utf-8") as f:
        return json.load(f)

@app.get("/protein/{protein_id}/structure")
def get_protein_structure(protein_id: str):
    """
    Simulates looking up structural models for yeast proteins. 
    Returns mapping if available.
    """
    # For demonstration, we simply check if it's a standard Yeast ORF format
    # In a real pipeline, we'd lookup the UniProt accession here.
    if protein_id.upper().startswith("Y"):
        return {
            "protein_id": protein_id.upper(),
            "structure_available": True,
            "source": "AlphaFold DB (Simulated Mapping)",
            # AlphaFold requires uniprot ID, but we provide a known yeast example PDB for the 3Dmol viewer
            "pdb_url": f"https://alphafold.ebi.ac.uk/files/AF-P0CX51-F1-model_v4.pdb" # Example yeast structure (Actin)
        }
    return {
        "protein_id": protein_id.upper(),
        "structure_available": False,
        "message": "No validated structural model is available for this protein in the current data source."
    }

@app.get("/network/{protein_id}/candidates")
def get_network_candidates(protein_id: str, limit: int = 25):
    """Generate missing candidate interactions for the neighborhood."""
    net_data = build_protein_network(protein_id)
    
    known_partners = set()
    all_nodes = set()
    for edge in net_data['edges']:
        if edge['source'] == protein_id.upper():
            known_partners.add(edge['target'])
        elif edge['target'] == protein_id.upper():
            known_partners.add(edge['source'])
            
    for node in net_data['nodes']:
        all_nodes.add(node['id'])
        
    candidates = all_nodes - known_partners - {protein_id.upper()}
    
    if not candidates:
        return {"query_protein": protein_id, "candidates": []}
        
    candidate_list = list(candidates)[:limit]
    pairs = [{"protein_a": protein_id, "protein_b": c} for c in candidate_list]
    
    # Batch predict
    res = predictor.predict_batch(pairs)
    
    # Format and sort
    out = []
    for r in res:
        out.append({
            "source": protein_id.upper(),
            "target": r["protein_b"],
            "probability": r["calibrated_probability"],
            "calibrated_probability": r["calibrated_probability"],
            "prediction_id": r["prediction_id"],
            "model_version": r.get("model_version", "v2.0-RF/LR"),
            "documentation_status": r["documentation_status"]
        })
        
    out = sorted(out, key=lambda x: x["probability"], reverse=True)
    return {"query_protein": protein_id, "candidates": out[:limit]}
