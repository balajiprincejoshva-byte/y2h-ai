from pydantic import BaseModel, Field
from typing import List, Optional, Tuple, Dict, Any

class PredictRequest(BaseModel):
    protein_a: str = Field(..., example="YFL039C")
    protein_b: str = Field(..., example="YAL001C")
    sequence_a: Optional[str] = None
    sequence_b: Optional[str] = None

class BatchPredictRequest(BaseModel):
    pairs: List[Tuple[str, str]] = Field(..., example=[("YFL039C", "YAL001C"), ("YFL039C", "YOR001W")])

class PredictResponse(BaseModel):
    prediction_id: str
    protein_a: str
    protein_b: str
    calibrated_probability: float
    confidence_band: str
    documentation_status: str
    model_version: str
    nearest_known_interactors: List[Tuple[str, float]]
    provenance_trace: Dict[str, Any]
    error: Optional[str] = None

class NetworkResponse(BaseModel):
    query_gene: str
    total_nodes: int
    total_edges: int
    nodes: List[Dict[str, Any]]
    edges: List[Dict[str, Any]]
