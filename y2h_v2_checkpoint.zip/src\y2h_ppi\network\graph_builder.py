import networkx as nx
import pandas as pd
from pathlib import Path
from typing import Dict, Any, List
from y2h_ppi.logger import logger

INTERIM_DIR = Path("data/interim")

def build_protein_network(gene_id: str, depth: int = 1, max_nodes: int = 50) -> Dict[str, Any]:
    """Construct NetworkX interaction neighborhood graph for a given gene ID."""
    pos_path = INTERIM_DIR / "positives_mapped.parquet"
    if not pos_path.exists():
        return {"nodes": [], "edges": []}
        
    df_pos = pd.read_parquet(pos_path)
    
    G = nx.Graph()
    gene_clean = gene_id.strip().upper()
    
    # Filter edges connected to gene_clean
    sub_df = df_pos[(df_pos['protein_a'] == gene_clean) | (df_pos['protein_b'] == gene_clean)]
    
    nodes = set([gene_clean])
    edges = []
    
    for _, row in sub_df.head(max_nodes).iterrows():
        pa, pb = row['protein_a'], row['protein_b']
        nodes.add(pa)
        nodes.add(pb)
        edges.append({"source": pa, "target": pb, "type": "documented_biogrid", "confidence": 1.0})
        
    node_list = [{"id": n, "label": n, "is_query": (n == gene_clean)} for n in nodes]
    return {
        "query_gene": gene_clean,
        "total_nodes": len(node_list),
        "total_edges": len(edges),
        "nodes": node_list,
        "edges": edges
    }
