import re
import gzip
import requests
import pandas as pd
from pathlib import Path
from typing import Dict, Tuple
from Bio import SeqIO
from y2h_ppi.logger import logger
from y2h_ppi.data.manifest import update_manifest_entry

RAW_DIR = Path("data/raw")
INTERIM_DIR = Path("data/interim")

SGD_FASTA_URL = "https://downloads.yeastgenome.org/sequence/S288C_reference/orf_protein/orf_trans_all.fasta.gz"
UNIPROT_FASTA_URL = "https://rest.uniprot.org/uniprotkb/stream?format=fasta&query=%28proteome%3AUP000002311%29"

def download_yeast_sequences(raw_dir: Path = RAW_DIR) -> Tuple[Path, str]:
    """Download yeast reference proteome FASTA file from SGD or UniProt."""
    raw_dir.mkdir(parents=True, exist_ok=True)
    target_path = raw_dir / "yeast_reference_proteome.fasta"
    
    # Try downloading official SGD ORF protein translations FASTA first (100% yeast ORF match)
    logger.info("Downloading SGD yeast ORF protein translations FASTA...")
    try:
        r = requests.get(SGD_FASTA_URL, timeout=60)
        r.raise_for_status()
        gz_data = gzip.decompress(r.content).decode("utf-8")
        with open(target_path, "w", encoding="utf-8") as f:
            f.write(gz_data)
        logger.info(f"Downloaded SGD reference proteome FASTA to {target_path}")
        return target_path, SGD_FASTA_URL
    except Exception as e:
        logger.warning(f"SGD FASTA download failed: {e}. Trying UniProt fallback...")
        
    # UniProt Fallback
    try:
        r = requests.get(UNIPROT_FASTA_URL, timeout=60)
        r.raise_for_status()
        with open(target_path, "w", encoding="utf-8") as f:
            f.write(r.text)
        logger.info(f"Downloaded UniProt proteome FASTA to {target_path}")
        return target_path, UNIPROT_FASTA_URL
    except Exception as ex:
        logger.error(f"Failed downloading proteome FASTA: {ex}")
        raise ex

def parse_yeast_fasta(fasta_path: Path) -> Tuple[Dict[str, str], int]:
    """Parse FASTA headers and map all ID variants (Systematic ORF names, symbols, SGDIDs) to sequence."""
    seq_dict = {}
    total_parsed = 0
    
    with open(fasta_path, "r", encoding="utf-8") as handle:
        for record in SeqIO.parse(handle, "fasta"):
            total_parsed += 1
            seq = str(record.seq).upper().replace("*", "")
            if not seq:
                continue
                
            header = record.description
            ids_found = set()
            
            # Record ID (first word in FASTA header, e.g. YAL001C or sp|P12345|...)
            rec_id = record.id.split("|")[1] if "|" in record.id else record.id
            ids_found.add(rec_id.upper())
            
            # Extract Systematic ORF identifiers (e.g. YFL039C, YAL001C, YOR001W)
            orf_matches = re.findall(r'\bY[A-Z]{2}\d{3}[WC](?:-[A-Z])?\b', header, re.IGNORECASE)
            for m in orf_matches:
                ids_found.add(m.upper())
                
            # Extract Gene Symbols & SGDIDs (e.g. GN=ACT1, SGDID:S000000001)
            for token in re.split(r'[\s|;=,:]+', header):
                clean_t = token.strip().upper()
                if len(clean_t) >= 3 and (clean_t.isalnum() or clean_t.startswith("S0000")):
                    ids_found.add(clean_t)
                    
            for pid in ids_found:
                if pid not in seq_dict:
                    seq_dict[pid] = seq
                    
    logger.info(f"Parsed {total_parsed} FASTA records mapping to {len(seq_dict)} protein ID keys.")
    return seq_dict, total_parsed

def map_sequences_to_positives(positives_df: pd.DataFrame, raw_dir: Path = RAW_DIR, interim_dir: Path = INTERIM_DIR) -> Tuple[pd.DataFrame, Dict[str, str]]:
    """Map protein sequences to BioGRID positive pairs and log mapping statistics."""
    fasta_path, url = download_yeast_sequences(raw_dir)
    seq_dict, raw_fasta_count = parse_yeast_fasta(fasta_path)
    
    all_proteins = set(positives_df['protein_a']).union(set(positives_df['protein_b']))
    mapped_proteins = {p: seq_dict[p] for p in all_proteins if p in seq_dict}
    
    coverage = len(mapped_proteins) / len(all_proteins) if all_proteins else 0.0
    logger.info(f"Protein sequence mapping coverage: {len(mapped_proteins)} / {len(all_proteins)} ({coverage:.2%})")
    
    # Filter positive pairs to those where both proteins have sequences
    positives_mapped = positives_df[
        positives_df['protein_a'].isin(mapped_proteins) & 
        positives_df['protein_b'].isin(mapped_proteins)
    ].copy().reset_index(drop=True)
    
    logger.info(f"BioGRID positive pairs after sequence mapping filter: {len(positives_mapped)} pairs.")
    
    # Save sequences parquet
    seq_df = pd.DataFrame(list(mapped_proteins.items()), columns=['protein_id', 'sequence'])
    seq_df.to_parquet(interim_dir / "protein_sequences.parquet", index=False)
    positives_mapped.to_parquet(interim_dir / "positives_mapped.parquet", index=False)
    
    update_manifest_entry(
        source_name="SGD Yeast Proteome Sequences",
        url=url,
        version="SGD Reference Proteome",
        raw_count=raw_fasta_count,
        filtered_count=len(mapped_proteins),
        description=f"Yeast proteome amino acid sequences mapped to BioGRID interactors ({coverage:.2%} coverage)."
    )
    
    return positives_mapped, mapped_proteins
